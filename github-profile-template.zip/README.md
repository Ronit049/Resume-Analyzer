# GitHub Profile SVG

1. Put your ASCII art in `ascii-art.txt`.
2. Run:
   ```bash
   python profile.py
   ```
3. Upload `generated_light_mode.svg` to your GitHub profile repository.
